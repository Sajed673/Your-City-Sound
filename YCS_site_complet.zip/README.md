# Your City Sound (YCS)

Your City Sound est un site web d’actualité musicale urbaine locale (Strasbourg & autres villes).

## Contenu :
- Actus musicales locales
- Événements urbains
- Mise en avant des artistes locaux
- Landing page avec newsletter
- Design responsive streetwear

## À venir :
- Intégration Mailchimp
- Scénario d’automation email
- Section artistes + clips

© 2025 – Projet éducatif ECORIS